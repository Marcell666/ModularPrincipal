#include <stdio.h>
#ifdef __linux__
	#include "conio.h"
#else
	#include <conio.h>
#endif
#include "keyCodeVar.h"

/* http://www.cplusplus.com/forum/unices/36461/ */

int drawOptions(int nOpcoes, char opcoes[][80]){
	int move;
	int i;
	int cursor=0;
	int soma=0;
	for(i=0;i<nOpcoes;i++)
		printf("   %s\n", opcoes[i]);
	
	//volta para o inicio
	printf("\r");
	fflush(stdout);
	//sobe para o topo
	for(i=0;i<nOpcoes;i++)
		printf("\033[A");
	fflush(stdout);
	while(1){
		//desenha cursor
		for(i=0;i<cursor;i++)
			printf("\n");
		printf(" > ");
		printf("\r");
				
		while(1){
			
			move = getArrowKey();
			if(move == VK_UP && cursor>0){ //para cima
				soma = -1;
				break;
			}
			if(move == VK_DOWN && cursor<nOpcoes-1){ //para baixo
				soma = 1;
				break;
			}
			if(move == VK_ENTER){
				for(i=cursor; i< nOpcoes; i++)
					printf("\n");
				printf("\r, ");
				return cursor;
			}
				
		}
		
		printf("   ");
		printf("\r");
		for(i=0;i<cursor;i++)
			printf("\033[A");

		cursor+=soma;
	}
}

int main(void){
	char opcoes[][80] = {
		"fazer login como professor",
		"fazer login como aluno",
		"fazer login como admin",
		"obter a triforce da coragem",
		"obter a triforce da sabedoria",
		"obter a triforce do poder"
	};
	int nOpcoes = 6;
	int i;
	
	calibrar();
	//initKey();

	for(i=0;i<5;i++)
		printf("opcao escolhida:%d\n", drawOptions(nOpcoes, opcoes));
	
	getchar();
	return 0;
}
