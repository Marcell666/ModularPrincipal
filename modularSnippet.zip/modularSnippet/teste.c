#include <stdio.h>
#include <unistd.h>

//#define func(format, …) testeFuncao (format __VA_OPT__(,) __VA_ARGS__)

//#define eprintf(format, …) fprintf (stderr, format, ##__VA_ARGS__)
#define FUNC_OWN
#ifndef FUNC_OWN
#pragma GCC poison testeFuncao
#endif

#ifdef FUNC_OWN
#define funcA testeFuncao1
#else
#define funcA testeFuncao2
#endif

#ifdef FUNC_OWN
#pragma GCC warning "este arquivo esta sendo usado incorretamente"
#endif


void testeFuncao(int num, char c){
	printf("hello %d %c world\n", num, c);
}

#define testeFuncao(a) testeFuncao(a, 'A')
#define func testeFuncao


/*

printf("HEllo\n");

CONSOLE_SCREEN_BUFFER_INFO coninfo;
HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
GetConsoleScreenBufferInfo(hConsole, &coninfo);
coninfo.dwCursorPosition.Y -= 1;    // move up one line
coninfo.dwCursorPosition.X += 5;    // move to the right the length of the word
SetConsoleCursorPosition(hConsole, coninfo.dwCursorPosition);

printf("world");

https://docs.microsoft.com/en-us/windows/console/console-screen-buffers

-----------------------------------------------------------------------------------------

#include <windows.h> //This is where you will get the SetConsolePosition and Coords struct
 
int main (void) {
	
	COORD coord;
	coord.X = 10;
	coord.Y = 1;
 
	std::cout << "Hello!" << std::endl;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
	std::cout << "World!?" ;
	return 0;
}

https://www.quora.com/How-can-you-move-back-up-a-line-in-c++

*/
int main(void){
	
	testeFuncao(3);
	testeFuncao(4, 'A');

	/*
	int i=0;
	char chars[] ="-\\|/"; 
	printf("\n");
	printf("testando\a\n");
	fflush(stdout);
	sleep(2);
	printf("\rmudou");
	fflush(stdout);
	sleep(1);
	printf("\b\b\bAAA\n");
	//printf("\033[A");
	printf("\b\b");
	printf("BB\n");
	//printf("\033[2J");

	printf("teste\r\n");
	while(1){
		printf("%c\r", chars[i% sizeof(chars)]);
		fflush(stdout);
		i++;
		if(i==sizeof(chars))
			i=0;
		sleep(1);
		//usleep(200000)
	}
	*/
	return 0;
}
