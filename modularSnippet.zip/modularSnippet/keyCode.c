#include <stdio.h>
#ifdef __linux__
	#include "conio.h"
#else
	#include <conio.h>
#endif	
int main(void){
	char msgs[][40] = {
		"pressione enter",
		"pressione backspace",
		"",
		"",
		"pressione a seta para cima",
		"pressione a seta para direita",
		"pressione a seta para baixo",
		"pressione a seta para esquerda"
	};
	int i;
	int n = 8;
	int key[8];
	int escape;
	for(i=0;i<n-6;i++){
		printf("por favor %s\n", msgs[i]);
		key[i] = getch();
	}
	escape = i;
	for(i=escape+2;i<n;i++){
		printf("por favor %s\n", msgs[i]);
		key[escape] = getch();
		key[escape+1] = getch();
		key[i] = getch();
	}
	
	printf("Copie a linha seguinte:\n");
	for(i=0;i<n;i++)
		printf("%d ", key[i]);
	printf("\nObrigado! Agora basta me enviar a linha anterior.\n");
	return 0;
}
