#define N_KEY 8

#define VK_ENTER key[0]
#define VK_BACKSPACE key[1]
#define VK_UP key[2]
#define VK_RIGHT key[3]
#define VK_DOWN key[4]
#define VK_LEFT key[5]
#define VK_ARROWA key[6]
#define VK_ARROWB key[7]

extern int nEscape;
extern int key[N_KEY];

void calibrar();
void initKey(void);
int getArrowKey();
