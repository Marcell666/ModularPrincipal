#include <stdio.h>
#ifdef __linux__
	#include "conio.h"
#else
	#include <conio.h>
#endif
#include "keyCodeReg.h"

int key[N_KEY];

void calibrar(){
	char msgs[][40] = {
		"pressione enter",
		"pressione backspace",
		"",
		"",
		"pressione a seta para cima",
		"pressione a seta para direita",
		"pressione a seta para baixo",
		"pressione a seta para esquerda"
	};
	int i;
	int n = N_KEY;
	int escape;
	printf("calibrando..\n");
	for(i=0;i<n-6;i++){
		printf("por favor %s\n", msgs[i]);
		key[i] = getch();
	}
	escape = i;
	for(i=escape+2;i<n;i++){
		printf("por favor %s\n", msgs[i]);
		key[escape] = getch();
		key[escape+1] = getch();
		key[i] = getch();
	}
	printf("Obrigado! \n Pressione enter para continuar.");
	getchar();
}

void initKey(void){
	FILE* f;
	int i=0;
	int buf;
	f=fopen("config", "rt");
	if(!f){
		printf("Arquivo de configuracao nao encontrado\n Calibragem necessaria\n");
		calibrar();
		f=fopen("config", "wt");
		if(f){
			for(i=0;i<N_KEY;i++)
				fprintf(f,"%d ", key[i]);
		}
		
	}
	else{
		while(fscanf(f,"%d", &buf)!=EOF)
			key[i++] = buf;
	}
	for(i=0;i<N_KEY;i++)
		printf("%d ", key[i]);
	printf("\n");
	fclose(f);
}

int getArrowKey(){
	int move;
	while(1){
		move = getch();
		if(move == VK_ENTER)
			return VK_ENTER;
		if(move!=VK_ARROWA)
			continue;
		move = getch();
		if(move!=VK_ARROWB)
			continue;
		move = getch();
		return move;
	}
}
