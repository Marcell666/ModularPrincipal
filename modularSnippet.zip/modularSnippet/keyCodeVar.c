#include <stdio.h>
#ifdef __linux__
	#include "conio.h"
#else
	#include <conio.h>
#endif
#include "keyCodeVar.h"

//typedef int (*VKB_comparaTecla)(int);

int nEscape;
int key[N_KEY];


void calibrar(){
	char msgs[][40] = {
		"pressione enter",
		"pressione backspace",
		"pressione a seta para cima",
		"pressione a seta para direita",
		"pressione a seta para baixo",
		"pressione a seta para esquerda"
		"",
		"",
	};
	//char keyTemp;
	//char arrowKey[3];
	int keyTemp;
	int arrowKey[3];
	int i, e;
	int n = N_KEY;
	int escape;
	printf("calibrando..\n");

	for(i=0;i<n-6;i++){
		printf("por favor %s\n", msgs[i]);
		key[i] = getch();
	}
	escape = 0;	
	for(i=i;i<n-2;i++){
		printf("por favor %s seguido da tecla 'enter'\n", msgs[i]);
		do{
			keyTemp = getch();
			if(keyTemp != VK_ENTER){
				arrowKey[escape] = keyTemp;
				//printf("arrowKey[%d] : %d\n", escape,arrowKey[escape]);
				escape++;
			}
		}while(keyTemp != VK_ENTER);
		
		nEscape = escape-1;//guardo o numero de teclas de escape
		for(e=0;e<nEscape;e++){
			//coloco cada tecla de escape no lugar devido no vetor de keys
			key[n-2+e] = arrowKey[e];
			//printf("mostrando arrow[%d]: %d\n", e, arrowKey[e]);
		}
		//printf("%d ", arrowKey[escape-1]);
		key[i] = arrowKey[escape-1];
		escape=0;
	}
	printf("\n");
	for(i=0;i<n;i++)
		printf("%d ", key[i]);
	printf("Obrigado! \n Pressione enter para continuar.");
	getchar();
}

void initKey(void){
	FILE* f;
	int i=0;
	int buf;
	f=fopen("config", "rt");
	if(!f){
		printf("Arquivo de configuracao nao encontrado\n Calibragem necessaria\n");
		calibrar();
		f=fopen("config", "wt");
		if(f){
			for(i=0;i<N_KEY;i++)
				fprintf(f,"%d ", key[i]);
		}
		
	}
	else{
		while(fscanf(f,"%d", &buf)!=EOF)
			key[i++] = buf;
	}
	for(i=0;i<N_KEY;i++)
		printf("%d ", key[i]);
	printf("\n");
	fclose(f);
}

/*
	retorna 1 se o valor passado por ret fizer parte de uma sequencia de caracteres correspnde a uma das setas cima ou baixo.
	A função para de pedir caracteres quando a sequencia deixa de ser valida
	O valor passado deve ser o primeiro caractere de uma sequencia que se deseja verificar
*/
int getArrowCode(int *ret){
	int move;
	int i;
	move = *ret;
	for(i=0;i<nEscape;i++){
		if(move != key[N_KEY-2+i])
			return 0;
		move = getch();
	}
	
	if(move==VK_UP || move==VK_DOWN){
//	if(move==VK_UP || move==VK_RIGHT || move==VK_DOWN || move==VK_LEFT){
		*ret = move;
		return 1;
	}
	return 0;
}
	

int getArrowKey(){
	int move;
	while(1){
		move = getch();
		if(move == VK_ENTER)
			return VK_ENTER;
		if(getArrowCode(&move))
			return move;
	}
}

/*
	TODO
	melhorar isso, para o futuro

int VKB_leComparaSoSetas(int *t){	
	return *t==VK_ENTER || (getArrowCode(t));
}
int VKB_leComparaSoCimaBaixo(int *t){
	return *t==VK_ENTER || (getArrowCode(t) && (*t == VK_UP || *t == VK_DOWN));
}

int VKB_leComparaQuaseTudo(int *t){
	int ret = 0;
	ret = *t==VK_ENTER || *t==VK_ESCAPE || VK_BACKSPACE;
	if(ret) return ret;
	if(!getArrowCode(t) ) return 0;
	return *t == VK_UP || *t == VK_DOWN;
}

int getKey(VKB_ComparaTecla compara){
	int move;
	while(1){
		move = getch();
		if(compara(move))
			return move;
	}
}
*/
