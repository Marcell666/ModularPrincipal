/* reads from keypress, doesn't echo */
int getch(void);

/* reads from keypress, echoes */
int getche(void);
