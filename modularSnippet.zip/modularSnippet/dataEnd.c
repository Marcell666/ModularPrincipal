/***************************************************************************
*  $MCI Módulo de implementação: Módulo dataEndereco
*
*  Arquivo gerado:              dataEnd.C
*  Letras identificadoras:      DTE
*
*  Nome da base de software:    Fonte do módulo dataEndereco
*
*  Projeto: Disciplina INF 1301
*  Gestor:  DI/PUC-Rio
*  Autores: Bruce Marcellino, BM  
*
*
*  $HA Histórico de evolução:
*     Versão  Autor    			  Data     Observações
*       1.00   BM   26/11/2017 Desenvolvimento para T3.5 
*
*  $ED Descrição do módulo
*     Este modulo contém as funções específicas para criar, alterar e consultar
*     instâncias de data e endereço.
***************************************************************************/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/***********************************************************************
*
*  $TC Tipo de dados: Data
*
*
*  $ED Descrição do tipo
*     Estrutura que armazena os dados com dia, mes e ano.
*
***********************************************************************/
	struct data{
		int dia;
		int mes;
		int ano;
	} ;

/***********************************************************************
*
*  $TC Tipo de dados: Endereço
*
*
*  $ED Descrição do tipo
*     Estrutura que armazena dos dados um local.
*
***********************************************************************/


	struct endereco{
		char pais[DTE_TAM_STRING];
		char uf[DTE_TAM_UF]; 
			/* Unidade Federativa - Estados */
		char cidade[DTE_TAM_STRING];
		char bairro[DTE_TAM_STRING];
		char rua[DTE_TAM_STRING];
		int numero;
			/* numero do predio */
		char complemento[DTE_TAM_STRING];
			/*apartamento ou casa com numero //ex: apt 101 */
	};

/*****  Dados encapsulados no módulo  *****/
	
static int maxDias[] = {31,29,31,30,31,30,31,31,30,31,30,31};
		/* vetor contendo o máximo de dias válidos em cada mês. Usado na função verificaData */

/***** Protótipos das funções encapsuladas no módulo *****/

	DTE_tpCondRet mostraEndereco(Endereco* end);
	DTE_tpCondRet mostraData(Data* d);

	int verificaPais(char* pais);
	int verificaUf(char* uf);
	int verificaCidade(char* cidade);
	int verificaBairro(char* bairro);
	int verificaComplemento(char* complemento);
	int verificaNumero(int numero);
	int verificaRua(char* rua);
	int verificaData(int dia, int mes, int ano);

/*****  Código das funções exportadas pelo módulo  *****/

/***************************************************************************
*
*  Função: DTE Criar data
*  ****/
DTE_tpCondRet DTE_criaData(Data *data, int dia, int mes, int ano){
	return DTE_alteraDataNascimento(data, dia, mes, ano);
} /* Fim função: DTE Criar data */


DTE_tpCondRet DTE_criaEndereco(Endereco *endereco, char *pais, char *uf, char *cidade, char *bairro, char *rua, int numero, char *complemento){
	DTE_tpCondRet ret;

	do{
		/* Bloco para checar se os parametros para as alterações foram todos válidos */

		if((ret = DTE_alteraPais(endereco, pais)) 		!= DTE_CondRetOk) break; /* if */
		if((ret = DTE_alteraUf(endereco, uf)) 			!= DTE_CondRetOk) break; /* if */
		if((ret = DTE_alteraCidade(endereco, cidade)) 		!= DTE_CondRetOk) break; /* if */
		if((ret = DTE_alteraBairro(endereco, bairro)) 		!= DTE_CondRetOk) break; /* if */ 
		if((ret = DTE_alteraRua(endereco, rua))			!= DTE_CondRetOk) break; /* if */
		if((ret = DTE_alteraNumero(endereco, numero))		!= DTE_CondRetOk) break; /* if */
		if((ret = DTE_alteraComplemento(endereco, complemento))	!= DTE_CondRetOk) break; /* if */
	}while(0); 

	return ret;
} /* Fim função: DTE Criar endereco */

/***********************************************************************
*
*  $FC Função: DTE Mostra data
*
*  $FV Valor retornado
*     DTE_tpCondRet condição de retorno padrão do módulo
*     Retorna DTE_CondRetOk caso todos os dados tenham sido exibidos.
*
***********************************************************************/

	DTE_tpCondRet mostraData(Data* d){
		printf("Data de nascimento: ");
		printf("%d/%d/%d\n", d->dia, d->mes, d->ano);
		return DTE_CondRetOk;
	} /* Fim função: Mostra data */

/***********************************************************************
*
*  $FC Função: DTE Mostra endereço
*
*  $FV Valor retornado
*     DTE_tpCondRet condição de retorno padrão do módulo
*     Retorna DTE_CondRetOk caso todos os dados tenham sido exibidos.
*
***********************************************************************/

	DTE_tpCondRet mostraEndereco(Endereco* end){
		printf("Endereco:");
		printf(" %s, ", end->rua);
		printf("%d, ", end->numero);
		printf("%s, ", end->complemento);
		printf("%s, ", end->bairro);
		printf("%s, ", end->cidade);
		printf("%s - ", end->uf);
		printf("%s, \n", end->pais);
		return DTE_CondRetOk;
	} /* Fim função: DTE Mostra endereco */

/***************************************************************************
*
*  Função: DTE Consulta dia
*  ****/

	DTE_tpCondRet DTE_consultaDia(Data *data, int *dia){
		if(!data) return DTE_CondRetNaoExisteProf; /* if */
		*dia = data->dia;
		return DTE_CondRetOk;
	} /* Fim função: DTE Consulta dia */


/***************************************************************************
*
*  Função: DTE Consulta mês
*  ****/

	DTE_tpCondRet DTE_consultaMes(Data *data, int *mes){
		if(!data) return DTE_CondRetNaoExisteProf; /* if */
		*mes = data->mes;
		return DTE_CondRetOk;
	} /* Fim função: DTE Consulta mês */


/***************************************************************************
*
*  Função: DTE Consulta ano 
*  ****/

	DTE_tpCondRet DTE_consultaAno(Data *data, int *ano){
		if(!data) return DTE_CondRetNaoExisteProf; /* if */
		*ano = data->ano;
		return DTE_CondRetOk;
	} /* Fim função: DTE Consulta ano */


/***************************************************************************
*
*  Função: DTE Consulta país
*  ****/

	DTE_tpCondRet DTE_consultaPais(Endereco *endereco, char *pais){
		if(!endereco) return DTE_CondRetNaoExisteProf; /* if */
		strcpy(pais, endereco->pais);
		return DTE_CondRetOk;
	} /* Fim função: DTE Consulta país */


/***************************************************************************
*
*  Função: DTE Consulta uf
*  ****/

	DTE_tpCondRet DTE_consultaUf(Endereco *endereco, char *uf){
		if(!endereco) return DTE_CondRetNaoExisteProf; /* if */
		strcpy(uf, endereco->uf);
		return DTE_CondRetOk;
	} /* Fim função: DTE Consulta uf */


/***************************************************************************
*
*  Função: DTE Consulta cidade
*  ****/

	DTE_tpCondRet DTE_consultaCidade(Endereco *endereco, char *cidade){
		if(!endereco) return DTE_CondRetNaoExisteProf; /* if */
		strcpy(cidade, endereco->cidade);
		return DTE_CondRetOk;
	} /* Fim função: DTE Consulta cidade */


/***************************************************************************
*
*  Função: DTE Consulta bairro
*  ****/

	DTE_tpCondRet DTE_consultaBairro(Endereco *endereco, char *bairro){
		if(!endereco) return DTE_CondRetNaoExisteProf; /* if */
		strcpy(bairro, endereco->bairro);
		return DTE_CondRetOk;
	} /* Fim função: DTE Consulta bairro */


/***************************************************************************
*
*  Função: DTE Consulta rua
*  ****/

	DTE_tpCondRet DTE_consultaRua(Endereco *endereco, char *rua){
		if(!endereco) return DTE_CondRetNaoExisteProf; /* if */
		strcpy(rua, endereco->rua);
		return DTE_CondRetOk;
	} /* Fim função: DTE Consulta rua */


/***************************************************************************
*
*  Função: DTE Consulta numero
*  ****/

	DTE_tpCondRet DTE_consultaNumero(Endereco *endereco, int *numero){
		if(!endereco) return DTE_CondRetNaoExisteProf; /* if */
		*numero = endereco->numero;
		return DTE_CondRetOk;
	} /* Fim função: DTE Consulta numero */


/***************************************************************************
*
*  Função: DTE Consulta complemento
*  ****/

	DTE_tpCondRet DTE_consultaComplemento(Endereco *endereco, char *complemento){
		if(!endereco) return DTE_CondRetNaoExisteProf; /* if */
		strcpy(complemento, endereco->complemento);
		return DTE_CondRetOk;
	} /* Fim função: DTE Consulta complemento */


/***************************************************************************
*
*  Função: DTE Altera data
*  ****/

	DTE_tpCondRet DTE_alteraData(Data *data, int dia, int mes, int ano){
		if(data == NULL) return DTE_CondRetNaoExisteProf; /* if */
		if(verificaData(dia, mes, ano) == 0)
			return DTE_CondRetFormatoInvalido; /* if */
		data->ano = ano;
		data->mes = mes;
		data->dia = dia;
		return DTE_CondRetOk;
	} /* Fim função: DTE Altera data */


/***************************************************************************
*
*  Função: DTE Altera rua
*  ****/

	DTE_tpCondRet DTE_alteraRua(Endereco *endereco, char* rua){
		if(endereco == NULL || endereco == NULL)
			return DTE_CondRetNaoExisteProf; /* if */
		if(verificaRua(rua) == 0)
			return DTE_CondRetFormatoInvalido; /* if */
		// altera dados
		strcpy(endereco->rua,rua);
		return DTE_CondRetOk;
	} /* Fim função: DTE Altera rua */


/***************************************************************************
*
*  Função: DTE Altera rua
*  ****/

	DTE_tpCondRet DTE_alteraNumero(Endereco *endereco, int numero){
		if(endereco == NULL || endereco == NULL)
			return DTE_CondRetNaoExisteProf; /* if */
		if(verificaNumero(numero) == 0)
			return DTE_CondRetFormatoInvalido; /* if */
		endereco->numero = numero;
		return DTE_CondRetOk;
	} /* Fim função: DTE Altera numero */


/***************************************************************************
*
*  Função: DTE Altera complemento
*  ****/

	DTE_tpCondRet DTE_alteraComplemento(Endereco *endereco, char* complemento){
		if(endereco == NULL)
			return DTE_CondRetNaoExisteProf; /* if */
		if(verificaComplemento(complemento) == 0)
			return DTE_CondRetFormatoInvalido; /* if */
		strcpy(endereco->complemento, complemento);
		return DTE_CondRetOk;
	} /* Fim função: DTE Altera complemento */


/***************************************************************************
*
*  Função: DTE Altera bairro
*  ****/

	DTE_tpCondRet DTE_alteraBairro(Endereco *endereco, char* bairro){
		if(endereco == NULL)
			return DTE_CondRetNaoExisteProf; /* if */
		if(verificaBairro(bairro) == 0)
			return DTE_CondRetFormatoInvalido; /* if */
		strcpy(endereco->bairro,bairro);
		return DTE_CondRetOk;
	} /* Fim função: DTE Altera bairro */


/***************************************************************************
*
*  Função: DTE Altera cidade
*  ****/

	DTE_tpCondRet DTE_alteraCidade(Endereco *endereco, char* cidade){
		if(endereco == NULL)
			return DTE_CondRetNaoExisteProf; /* if */
		if(verificaCidade(cidade) == 0)
			return DTE_CondRetFormatoInvalido; /* if */
		strcpy(endereco->cidade,cidade);
		return DTE_CondRetOk;
	} /* Fim função: DTE Altera cidade */


/***************************************************************************
*
*  Função: DTE Altera UF
*  ****/

	DTE_tpCondRet DTE_alteraUf(Endereco *endereco, char* uf){
		if(endereco == NULL)
			return DTE_CondRetNaoExisteProf; /* if */
		if(verificaUf(uf) == 0)
			return DTE_CondRetFormatoInvalido; /* if */
		strcpy(endereco->uf,uf);
		return DTE_CondRetOk;
	} /* Fim função: DTE Altera UF*/


/***************************************************************************
*
*  Função: DTE Altera país
*  ****/

DTE_tpCondRet DTE_alteraPais(Endereco *endereco, char* pais){
	if( endereco == NULL)
		return DTE_CondRetNaoExisteProf; /* if */
	if(verificaPais(pais) == 0)
		return DTE_CondRetFormatoInvalido; /* if */
	strcpy(endereco->pais,pais);
	return DTE_CondRetOk;
} /* Fim função: DTE Altera UF*/
 

/***********************************************************************
*
*  $FC Função: DTE Verifica Data
*
*  $FV Valor retornado
*     Inteiro 0 ou 1.
*     Retorna 1 caso a data seja válida, retorna 0 caso contrário.
*
***********************************************************************/

	int verificaData(int dia, int mes, int ano){
		if(dia < 1 || ano < DTE_MIN_ANO || dia > maxDias[mes-1]) return 0;
		return 1;
	} /* Fim função: Verifica data*/


/***********************************************************************
*
*  $FC Função: DTE Verifica rua
*
*  $FV Valor retornado
*     Inteiro 0 ou 1.
*     Retorna 1 caso a rua seja válida, retorna 0 caso contrário.
*
***********************************************************************/

	int verificaRua(char* rua){
		int tamRua = strlen(rua);
		if(rua == NULL || tamRua == 0 || tamRua >= DTE_TAM_STRING)
			return 0; /* if */
		return 1;
	} /* Fim função: Verifica rua*/


/***********************************************************************
*
*  $FC Função: DTE Verifica numero
*
*  $FV Valor retornado
*     Inteiro 0 ou 1.
*     Retorna 1 caso o numero seja válido, retorna 0 caso contrário.
*
***********************************************************************/

	int verificaNumero(int numero){
		if(numero < 0)
			return 0; /* if */
		return 1;
	} /* Fim função: Verifica numero*/


/***********************************************************************
*
*  $FC Função: DTE Verifica Complemento
*
*  $FV Valor retornado
*     Inteiro 0 ou 1.
*     Retorna 1 caso o complemento seja válido, retorna 0 caso contrário.
*
***********************************************************************/

	int verificaComplemento(char* complemento){
		int tamComplemento = strlen(complemento);
		if( tamComplemento >= DTE_TAM_STRING)
			return 0; /* if */
		return 1;
	} /* Fim função: Verifica complemento*/

/***********************************************************************
*
*  $FC Função: DTE Verifica bairro
*
*  $FV Valor retornado
*     Inteiro 0 ou 1.
*     Retorna 1 caso bairro seja válido, retorna 0 caso contrário.
*
***********************************************************************/

	int verificaBairro(char* bairro){
		int tamBairro = strlen(bairro);
		if(bairro == NULL || tamBairro == 0 || tamBairro >= DTE_TAM_STRING)
			return 0; /* if */
		return 1;
	} /* Fim função: Verifica bairro*/

/***********************************************************************
*
*  $FC Função: DTE Verifica cidade
*
*  $FV Valor retornado
*     Inteiro 0 ou 1.
*     Retorna 1 caso cidade seja válida, retorna 0 caso contrário.
*
***********************************************************************/

	int verificaCidade(char* cidade){
		int tamCidade = strlen(cidade);
		if(cidade == NULL || tamCidade == 0 || tamCidade >= DTE_TAM_STRING)
			return 0; /* if */
		return 1;
	} /* Fim função: Verifica cidade*/


/***********************************************************************
*
*  $FC Função: DTE Verifica Uf
*
*  $FV Valor retornado
*     Inteiro 0 ou 1.
*     Retorna 1 caso uf seja válido, retorna 0 caso contrário.
*
***********************************************************************/

	int verificaUf(char* uf){
		int tamUf = strlen(uf);
		if(uf == NULL || tamUf == 0 || tamUf >= DTE_TAM_UF)
			return 0; /* if */
		return 1;
	} /* Fim função: Verifica complemento*/


/***********************************************************************
*
*  $FC Função: DTE Verifica pais
*
*  $FV Valor retornado
*     Inteiro 0 ou 1.
*     Retorna 1 caso o pais seja válido, retorna 0 caso contrário.
*
***********************************************************************/

	int verificaPais(char* pais){
		int tamPais =  strlen(pais);
		if(pais == NULL || tamPais == 0 || tamPais >= DTE_TAM_STRING)
			return 0; /* if */
		return 1;
	} /* Fim função: Verifica país*/


