#include <stdio.h>
#include <stdlib.h>
#include "gradeCurricular.h"



int main(void){
	char nome[80];
	int G1, G2, G3, G4;
	int situacao;
	float media;
	GRC_tpCondRet ret;
	G1 = 1;
	G2 = 10;
	G3 = 6;
	G4 = 7;
	ret = GRC_cria();
	ret = GRC_cadastra( "Modular" , "INF1301", 4, "Programacao Modular, Ardt Von Stadt", "NaoVouEscrever muito pois o LimiteE curto", 1);
	ret = GRC_cadastra( "Prog2" , "INF1007", 4, "C para idiotas", "Listas, ordenacao e TAD", 2);
	printf("adicionar preReq\n");
	printf("preReq %d\n", GRC_inserePreRequisito("INF1007"));
	printf("preReq %d\n", GRC_inserePreRequisito("INF1007"));
	printf("preReq %d\n", GRC_inserePreRequisito("INF1007"));
	ret = GRC_mostraTodas();
	GRC_buscaPorCodigo("INF1301");
	GRC_attSituacaoDisCorrente(G1,G2,G3,G4, &media, &situacao);
		printf("\n A media eh: %f. Situacao:", media);
	if(situacao == 1)
		printf("aprovado");
	else
		printf("reprovado");
	printf("retF %d\n", ret);
	printf("retNome %d\n", GRC_consultaNome(nome));
	printf("%s\n", nome);
	GRC_limpa();
	GRC_libera();
	printf("FIM\n");
	return 0;
}
